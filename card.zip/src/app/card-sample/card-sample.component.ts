import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {  trigger,  state,  style,  animate,  transition,} from '@angular/animations';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@Component({
  selector: 'app-card-sample',
  templateUrl: './card-sample.component.html',
  styleUrls: ['./card-sample.component.scss'],
  animations:[
    trigger('divState',[
      state('normal',style({
      })),
      state('highlighted',style(
        {
       }
      )),
      transition('normal => highlighted',animate(3000)),
      transition('highlighted => normal',animate(3000))
    ])
  ]
})
export class CardSampleComponent implements OnInit {
  inital:any = 0;
  state='normal'
  constructor(private httpService:HttpClient) {

   }
   selectedIndex: number;

  datas:any[];
  ngOnInit() {
    this.httpService.get('../../assets/data.json').subscribe(
      data => {
        this.datas = data as any
        console.log(this.datas[0])
      }

    )
    this.selectedIndex = 0;
  }

  next(){
    this.state=='normal' ?  this.state='highlighted': this.state ='normal'
    ++this.selectedIndex;
  }

  prev(){
    --this.selectedIndex;
  }



}
